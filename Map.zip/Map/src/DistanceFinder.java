
import java.util.*;
import java.io.*;
/**
 * / Project: Map
     Class: DistanceFinder.java
     Author: Shawnaundrae Davidson
     Date: 11.5.25
     Class for simulating finding the shortest distance
     from a city to all other cities.
*/
public class DistanceFinder
{
   private String startFrom;
   private Map<String, HashSet<map.DistanceTo>> directConnections;

   /**
      Construct a Distance finder.
      @param filename the file containing the connections.
   */
   public DistanceFinder(String filename)
   {
      // Read the file and intialize the instance variables
      //. . .
      //use HashMap

      directConnections = new HashMap<>();

      try(Scanner in = new Scanner (new File("src/" + filename))) {
         if (!in.hasNext()) {
            System.out.println("File is empty.");
            return;
         }

         while (in.hasNext()) {
            String city1 = in.next();
            String city2 = in.next();
            int dist = in.nextInt();

            if (startFrom == null) {
               startFrom = city1; // Set first city
            }

            addConnection(city1, city2, dist);
            addConnection(city2, city1, dist);
         }


      } catch (FileNotFoundException e) {
         System.out.println("File not found: " + filename);
      }
   }

   private void addConnection(String city1, String city2, int dist) {
      directConnections.putIfAbsent(city1, new HashSet<>());
      directConnections.get(city1).add(new map.DistanceTo(city2, dist));
   }

   /**
      Return the city that we start from.
   */
   public String getStartingCity()
   {
      return startFrom;
   }

   /**
      Return the shortest distances.
      @return the shortest distances.
   */
   public Map<String, Integer> shortestDistances()
   {
      // Follow the algorithm in the instruction
      // Remember the starting point is the first city in the file.
      //. . .
      //use TreeMap


      Map<String, Integer> shortestKnownDistance = new TreeMap<>();
      PriorityQueue<map.DistanceTo> pq = new PriorityQueue<>();

      // start from the starting city
      pq.add(new map.DistanceTo(startFrom, 0));
      shortestKnownDistance.put(startFrom, 0);

      while (!pq.isEmpty()) {
         map.DistanceTo current = pq.poll();
         String currentCity = current.getTarget();
         int currentDist = current.getDistance();

         // skip outdated city entries
         if (currentDist > shortestKnownDistance.get(currentCity)) continue;

         // visit neighboring cities
         for (map.DistanceTo neighbor : directConnections.getOrDefault(currentCity, new HashSet<>())) {
            int newDist = currentDist + neighbor.getDistance();

            if (!shortestKnownDistance.containsKey(neighbor.getTarget())
                    || newDist < shortestKnownDistance.get(neighbor.getTarget())) {
               shortestKnownDistance.put(neighbor.getTarget(), newDist);
               pq.add(new map.DistanceTo(neighbor.getTarget(), newDist));
            }
         }
      }

      return shortestKnownDistance;



   }
}
